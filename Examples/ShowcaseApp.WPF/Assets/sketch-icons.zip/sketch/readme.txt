"Sketch" is a set of 16 free icons designed by Double-J Design<http://www.doublejdesign.co.uk> 
excusively for IconDock<http://icondock.com>. The icons are truly drawn by hand using a pen tablet. It provides a 
rich pencil sketch feel and will be perfect for websites or designs using sketchy style. The 
set includes 16 free icons in two different color schemes (black/white and colored) and it is 
licensed under CC 3.0 Attribution license. You can use them for free in your personal or 
commercial project but an attribution to the author (Double-J Design<http://www.doublejdesign.co.uk>)
is required. It is not allowed to use them in any kind of integration in a product that is for sale.